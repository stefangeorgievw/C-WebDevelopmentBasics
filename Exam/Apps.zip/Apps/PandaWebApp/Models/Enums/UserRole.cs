﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PandaWebApp.Models.Enums
{
    public enum  UserRole
    {
        User = 1,
        Admin = 2,
    }
}
