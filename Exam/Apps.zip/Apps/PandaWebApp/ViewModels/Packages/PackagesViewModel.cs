﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PandaWebApp.ViewModels.Packages
{
     public class PackagesViewModel
    {
        public string Description { get; set; }

        public int Id { get; set; }

        public double Weight { get; set; }

        public string ShippingAddress { get; set; }

        public string Recipient { get; set; }


    }
}
