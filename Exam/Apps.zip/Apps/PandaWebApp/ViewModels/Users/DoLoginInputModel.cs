﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PandaWebApp.ViewModels.Users
{
    public class DoLoginInputModel
    {
        public string Username { get; set; }

        public string Password { get; set; }
    }
}
