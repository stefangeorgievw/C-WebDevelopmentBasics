﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PandaWebApp.ViewModels.Home
{
    public class PackageViewModel
    {
        public int Id { get; set; }

        public string Description { get; set; }
    }
}
